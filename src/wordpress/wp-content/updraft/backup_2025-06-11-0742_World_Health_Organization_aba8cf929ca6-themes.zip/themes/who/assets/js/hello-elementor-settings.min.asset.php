<?php return array('dependencies' => array('react', 'react-dom', 'wp-api-fetch', 'wp-components', 'wp-data', 'wp-i18n', 'wp-notices'), 'version' => 'c2065875c24a5b8d6aa5');
