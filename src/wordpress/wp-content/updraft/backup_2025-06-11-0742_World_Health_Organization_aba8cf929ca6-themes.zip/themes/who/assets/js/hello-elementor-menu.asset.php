<?php return array('dependencies' => array(), 'version' => 'b43f644acb358dd5e65c');
