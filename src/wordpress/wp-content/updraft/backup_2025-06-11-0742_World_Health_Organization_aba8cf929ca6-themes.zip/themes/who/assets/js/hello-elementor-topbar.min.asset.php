<?php return array('dependencies' => array('react', 'react-dom', 'wp-i18n'), 'version' => '7cee21c093f62268c41f');
