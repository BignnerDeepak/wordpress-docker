<?php return array('dependencies' => array(), 'version' => 'b7466eb654ff3936a8ef');
