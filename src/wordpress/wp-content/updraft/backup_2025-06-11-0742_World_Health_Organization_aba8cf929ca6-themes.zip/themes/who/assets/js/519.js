"use strict";
(self["webpackChunkelementor_hello_theme"] = self["webpackChunkelementor_hello_theme"] || []).push([[519],{

/***/ 7519:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1609);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _elementor_ui_SvgIcon__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5422);
'use client';




const BrandYoutubeIcon = react__WEBPACK_IMPORTED_MODULE_0__.forwardRef((props, ref) => {
  return (0,react__WEBPACK_IMPORTED_MODULE_0__.createElement)(_elementor_ui_SvgIcon__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .A, {
    viewBox: "0 0 24 24",
    ...props,
    ref: ref
  }, (0,react__WEBPACK_IMPORTED_MODULE_0__.createElement)("path", {
    fillRule: "evenodd",
    clipRule: "evenodd",
    d: "M3.95964 2.64459C2.76302 2.64459 1.79297 3.61464 1.79297 4.81126V12.8113C1.79297 14.0079 2.76302 14.9779 3.95964 14.9779H16.6263C17.8229 14.9779 18.793 14.0079 18.793 12.8113V4.81126C18.793 3.61464 17.8229 2.64459 16.6263 2.64459H3.95964ZM0.79297 4.81126C0.79297 3.06236 2.21073 1.64459 3.95964 1.64459H16.6263C18.3752 1.64459 19.793 3.06236 19.793 4.81126V12.8113C19.793 14.5602 18.3752 15.9779 16.6263 15.9779H3.95964C2.21073 15.9779 0.79297 14.5602 0.79297 12.8113V4.81126ZM7.71329 4.87616C7.87004 4.78741 8.06242 4.78983 8.21688 4.88251L13.5502 7.88251C13.7008 7.97287 13.793 8.13563 13.793 8.31126C13.793 8.48689 13.7008 8.64964 13.5502 8.74001L8.21688 11.74C8.06242 11.8327 7.87004 11.8351 7.71329 11.7464C7.55653 11.6576 7.45964 11.4914 7.45964 11.3113V5.31126C7.45964 5.13112 7.55653 4.96491 7.71329 4.87616ZM8.45964 6.19435V10.4282L12.3211 8.31126L8.45964 6.19435Z"
  }));
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BrandYoutubeIcon);

/***/ })

}]);